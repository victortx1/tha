/**
 * profile.js — editor do perfil com foto escolhida, gênero, preview e Firebase.
 */
import { auth, db } from './firebase.js';
import { watchAuth } from './auth.js';
import { THASec } from './security.js';
import { doc, getDoc, setDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

const BANNERS = {
  'agent-pink': 'linear-gradient(135deg,#fff5fb,#ffc7df 50%,#ff7eb6)',
  'white-premium': 'linear-gradient(135deg,#ffffff,#fff0f8 55%,#f1f1f1)',
  'hud-rosa': 'linear-gradient(135deg,#fff,#ffd8ea 45%,#ff5fa8)',
  'angel-gamer': 'linear-gradient(135deg,#fff7fc,#ffd4ec 55%,#ff9bd0)'
};

const GENDER_LABELS = {
  'nao-informar': 'Não informado',
  menina: 'Menina',
  homem: 'Homem',
  outro: 'Outro'
};

let selectedPhotoId = 'google';
let googlePhotoURL = '';
let currentUID = null;

function svgAvatar(label, bg1, bg2, fg = '#ffffff') {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 220 220">
    <defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="${bg1}"/><stop offset="1" stop-color="${bg2}"/></linearGradient></defs>
    <rect width="220" height="220" rx="54" fill="url(#g)"/>
    <circle cx="110" cy="92" r="38" fill="${fg}" opacity=".92"/>
    <path d="M46 194c11-42 40-65 64-65s53 23 64 65" fill="${fg}" opacity=".92"/>
    <path d="M37 57h32M151 57h32M57 37v32M163 37v32" stroke="${fg}" stroke-width="8" stroke-linecap="round" opacity=".55"/>
    <text x="110" y="205" text-anchor="middle" font-family="Arial" font-size="20" font-weight="900" fill="${fg}" opacity=".8">${label}</text>
  </svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

const PHOTO_OPTIONS = [
  { id: 'google', label: 'Google', url: '' },
  { id: 'tha-01', label: 'Rosa Agent', url: svgAvatar('THA 01', '#ff7eb6', '#ffd6e8') },
  { id: 'tha-02', label: 'Clutch Pink', url: svgAvatar('THA 02', '#ff4f8f', '#ffe5f1') },
  { id: 'tha-03', label: 'Angel', url: svgAvatar('THA 03', '#ffb3d9', '#ffffff', '#ff4f8f') },
  { id: 'tha-04', label: 'HUD Girl', url: svgAvatar('THA 04', '#ffc7df', '#ff5fa8') },
  { id: 'tha-05', label: 'Premium', url: svgAvatar('THA 05', '#ffffff', '#ffd4ec', '#ff5fa8') },
  { id: 'tha-06', label: 'Neon Soft', url: svgAvatar('THA 06', '#ff8bc7', '#ffeaf5') }
];

async function loadUserProfile(uid) {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? snap.data() : null;
}

function getPhotoURL() {
  if (selectedPhotoId === 'google') return googlePhotoURL || PHOTO_OPTIONS[1].url;
  return PHOTO_OPTIONS.find((photo) => photo.id === selectedPhotoId)?.url || PHOTO_OPTIONS[1].url;
}

function getFormData() {
  const get = (id) => document.getElementById(id)?.value || '';
  return {
    nickname: THASec.clean(get('nickname'), 40),
    bio: THASec.clean(get('bio'), 160),
    gender: ['nao-informar', 'menina', 'homem', 'outro'].includes(get('gender')) ? get('gender') : 'nao-informar',
    profileImage: selectedPhotoId,
    profileImageURL: getPhotoURL(),
    banner: Object.keys(BANNERS).includes(get('banner')) ? get('banner') : 'agent-pink',
    color: THASec.validColor(get('color')) ? get('color') : '#ff7eb6',
    cardStyle: get('cardStyle') || 'agent',
    socialLinks: THASec.socialLinks({
      tiktok: get('tiktok'),
      instagram: get('instagram'),
      youtube: get('youtube'),
      discord: get('discord'),
      linktree: get('linktree')
    })
  };
}

function renderPhotoChoices() {
  const wrap = document.querySelector('#photoChoices');
  if (!wrap) return;
  wrap.textContent = '';
  PHOTO_OPTIONS.forEach((photo) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `photo-choice ${selectedPhotoId === photo.id ? 'active' : ''}`;

    const img = document.createElement('img');
    img.alt = photo.label;
    img.src = photo.id === 'google' ? (googlePhotoURL || PHOTO_OPTIONS[1].url) : photo.url;

    const span = document.createElement('span');
    span.textContent = photo.label;

    btn.append(img, span);
    btn.addEventListener('click', () => {
      selectedPhotoId = photo.id;
      renderPhotoChoices();
      updatePreview();
    });
    wrap.appendChild(btn);
  });
}

function fillForm(profile) {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value || '';
  };
  set('nickname', profile.nickname);
  set('bio', profile.bio);
  set('gender', profile.gender || 'nao-informar');
  set('banner', profile.banner || 'agent-pink');
  set('color', profile.color || '#ff7eb6');
  set('cardStyle', profile.cardStyle || 'agent');
  set('tiktok', profile.socialLinks?.tiktok || '');
  set('instagram', profile.socialLinks?.instagram || '');
  set('youtube', profile.socialLinks?.youtube || '');
  set('discord', profile.socialLinks?.discord || '');
  set('linktree', profile.socialLinks?.linktree || '');
  selectedPhotoId = profile.profileImage || 'google';
  renderPhotoChoices();
  updatePreview();
  renderPublicProfile(profile);
}

function renderPublicProfile(profile = getFormData()) {
  const data = { ...getFormData(), ...profile };
  const setText = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.textContent = value || '';
  };
  const photo = document.getElementById('publicPhoto');
  if (photo) photo.src = data.profileImageURL || getPhotoURL();
  const banner = document.querySelector('.public-banner');
  if (banner) banner.style.background = BANNERS[data.banner] || BANNERS['agent-pink'];
  setText('publicName', data.nickname || 'Agente THA');
  setText('publicBio', data.bio || 'Perfil de agente da comunidade THA.');
  setText('publicGender', GENDER_LABELS[data.gender] || 'Não informado');
  setText('publicStyle', data.cardStyle || 'agent');
}

function updatePreview() {
  const data = getFormData();
  const preview = document.querySelector('#profilePreview');
  if (!preview) return;
  preview.dataset.style = data.cardStyle;
  preview.style.setProperty('--agent-color', data.color || '#ff7eb6');
  preview.querySelector('.preview-banner').style.background = BANNERS[data.banner] || BANNERS['agent-pink'];
  preview.querySelector('.preview-avatar').src = data.profileImageURL;
  preview.querySelector('.preview-name').textContent = data.nickname || 'Agente THA';
  preview.querySelector('.preview-bio').textContent = data.bio || 'Perfil de agente da comunidade THA.';
  preview.querySelector('.preview-gender').textContent = GENDER_LABELS[data.gender] || 'Não informado';
  preview.querySelector('.preview-style').textContent = data.cardStyle || 'agent';
  renderPublicProfile(data);
}

async function saveCurrentProfile(uid) {
  if (!THASec.rateLimit('save-profile', 1800)) {
    THASec.toast('Aguarde um pouco antes de salvar novamente.', 'error');
    return;
  }
  if (!THASec.ownProfile(auth.currentUser?.uid, uid)) {
    THASec.toast('Você só pode editar o seu próprio perfil.', 'error');
    return;
  }

  const data = getFormData();
  if (!THASec.validNickname(data.nickname)) {
    THASec.toast('Nickname inválido. Use até 40 caracteres.', 'error');
    return;
  }

  try {
    await setDoc(doc(db, 'users', uid), { ...data, updatedAt: serverTimestamp() }, { merge: true });
    await setDoc(doc(db, 'profiles', uid), {
      uid,
      nickname: data.nickname,
      bio: data.bio,
      gender: data.gender,
      profileImage: data.profileImage,
      profileImageURL: data.profileImageURL,
      banner: data.banner,
      color: data.color,
      cardStyle: data.cardStyle,
      socialLinks: data.socialLinks,
      updatedAt: serverTimestamp()
    }, { merge: true });
    THASec.toast('Perfil salvo com sucesso!', 'ok');
    renderPublicProfile(data);
    showEditor(false);
  } catch (error) {
    console.warn('[save profile]', error);
    THASec.toast('Erro ao salvar perfil.', 'error');
  }
}

function showEditor(show) {
  const editor = document.querySelector('#profileEditor');
  if (editor) editor.hidden = !show;
  const btn = document.querySelector('#editToggle');
  if (btn) btn.textContent = show ? 'Editando...' : 'Editar perfil';
}

export function initProfilePage() {
  document.querySelectorAll('input, textarea, select').forEach((el) => el.addEventListener('input', updatePreview));
  document.querySelector('#editToggle')?.addEventListener('click', () => showEditor(true));
  document.querySelector('#closeEditor')?.addEventListener('click', () => showEditor(false));

  watchAuth(async (user) => {
    const authBox = document.querySelector('#authBox');
    const area = document.querySelector('#profileArea');
    currentUID = user?.uid || null;

    if (!user) {
      if (authBox) authBox.hidden = false;
      if (area) area.hidden = true;
      return;
    }

    googlePhotoURL = user.photoURL || '';
    if (authBox) authBox.hidden = true;
    if (area) area.hidden = false;

    renderPhotoChoices();
    const profile = await loadUserProfile(user.uid);
    if (profile) fillForm(profile);
    else updatePreview();

    const saveBtn = document.querySelector('#saveProfile');
    if (saveBtn) saveBtn.onclick = () => saveCurrentProfile(user.uid);
  });
}

document.addEventListener('DOMContentLoaded', initProfilePage);
