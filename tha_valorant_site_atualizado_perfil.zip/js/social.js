/**
 * social.js — troque os links reais da THA aqui.
 */
export const SOCIAL_LINKS = {
  tiktok: 'https://www.tiktok.com/@tha.oficial',
  instagram: 'https://www.instagram.com/tha.oficial',
  youtube: 'https://www.youtube.com/@tha',
  discord: 'https://discord.gg/',
  linktree: 'https://linktr.ee/'
};

const SOCIALS = [
  { key:'tiktok', name:'TikTok', icon:'♪', text:'Vídeos, trends e Valorant.' },
  { key:'instagram', name:'Instagram', icon:'◎', text:'Fotos, stories e bastidores.' },
  { key:'youtube', name:'YouTube', icon:'▶', text:'Conteúdos longos e cortes.' },
  { key:'discord', name:'Discord', icon:'#', text:'Comunidade e squad.' },
  { key:'linktree', name:'Linktree', icon:'↗', text:'Todos os links oficiais.' }
];

export function renderSocialCards(target = '#socialGrid') {
  const grid = document.querySelector(target);
  if (!grid) return;
  grid.textContent = '';

  SOCIALS.forEach((item) => {
    const card = document.createElement('article');
    card.className = 'social-card';

    const icon = document.createElement('div');
    icon.className = 'social-icon';
    icon.textContent = item.icon;

    const title = document.createElement('h3');
    title.textContent = item.name;

    const text = document.createElement('p');
    text.textContent = item.text;

    const link = document.createElement('a');
    link.className = 'btn btn-primary';
    link.href = SOCIAL_LINKS[item.key] || '#';
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = `Abrir ${item.name}`;

    card.append(icon, title, text, link);
    grid.appendChild(card);
  });
}

document.addEventListener('DOMContentLoaded', () => renderSocialCards());
