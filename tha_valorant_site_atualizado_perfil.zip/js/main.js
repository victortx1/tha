/**
 * main.js — navegação, HUD, partículas leves e estado de login.
 */
import { watchAuth, logout } from './auth.js';
import { THASec } from './security.js';

function setupMenu() {
  const btn = document.querySelector('.menu-btn');
  const menu = document.querySelector('.nav-links');
  if (!btn || !menu) return;

  btn.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

function setupAuthUI() {
  watchAuth((user) => {
    document.querySelectorAll('[data-login-only]').forEach((el) => { el.hidden = !user; });
    document.querySelectorAll('[data-logout-only]').forEach((el) => { el.hidden = Boolean(user); });

    const name = document.querySelector('#navName');
    if (name) name.textContent = user ? THASec.clean(user.displayName || 'Agente', 40) : '';
  });

  document.querySelectorAll('[data-logout]').forEach((btn) => btn.addEventListener('click', logout));
}

function animateHudNumbers() {
  document.querySelectorAll('[data-count]').forEach((el) => {
    const end = Number(el.dataset.count || 0);
    let current = 0;
    const step = Math.max(1, Math.ceil(end / 40));
    const timer = setInterval(() => {
      current += step;
      if (current >= end) {
        current = end;
        clearInterval(timer);
      }
      el.textContent = String(current);
    }, 25);
  });
}

function setupReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) {
    items.forEach((el) => el.classList.add('visible'));
    return;
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) entry.target.classList.add('visible');
    });
  }, { threshold: 0.16 });

  items.forEach((el) => io.observe(el));
}

document.addEventListener('DOMContentLoaded', () => {
  setupMenu();
  setupAuthUI();
  setupReveal();
  animateHudNumbers();
});
