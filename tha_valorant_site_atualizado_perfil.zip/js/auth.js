/**
 * auth.js — login Google, logout e criação do perfil.
 */
import { auth, db, googleProvider } from './firebase.js';
import {
  signInWithPopup,
  signOut,
  onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { THASec } from './security.js';

const DEFAULT_BADGES = [1, 6];

export async function loginGoogle() {
  if (!THASec.rateLimit('login', 1800)) return;
  try {
    const result = await signInWithPopup(auth, googleProvider);
    await createOrUpdateUser(result.user);
    THASec.toast(`Bem-vinda, ${THASec.clean(result.user.displayName || 'Agente', 40)}!`, 'ok');
  } catch (error) {
    console.warn('[loginGoogle]', error);
    THASec.toast('Não foi possível entrar com Google.', 'error');
  }
}

export async function logout() {
  try {
    await signOut(auth);
    THASec.toast('Você saiu da conta.', 'ok');
    setTimeout(() => {
      const isPage = location.pathname.includes('/pages/');
      location.href = isPage ? '../index.html' : 'index.html';
    }, 800);
  } catch (error) {
    console.warn('[logout]', error);
  }
}

export async function createOrUpdateUser(user) {
  if (!user) return;
  const userRef = doc(db, 'users', user.uid);
  const publicRef = doc(db, 'profiles', user.uid);
  const snap = await getDoc(userRef);

  if (!snap.exists()) {
    const displayName = THASec.clean(user.displayName || 'Agente THA', 40);
    const payload = {
      uid: user.uid,
      displayName,
      photoURL: user.photoURL || '',
      nickname: displayName,
      bio: 'Agente da THA. Valorant, rosa e energia gamer.',
      avatar: '🌸',
      gender: 'nao-informar',
      profileImage: 'google',
      profileImageURL: user.photoURL || '',
      banner: 'agent-pink',
      theme: 'rosa-claro',
      color: '#ff7eb6',
      cardStyle: 'agent',
      socialLinks: { tiktok: '', instagram: '', youtube: '', discord: '', linktree: '' },
      unlockedBadges: DEFAULT_BADGES,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    await setDoc(userRef, payload);
    await setDoc(publicRef, {
      uid: user.uid,
      nickname: payload.nickname,
      bio: payload.bio,
      avatar: payload.avatar,
      gender: payload.gender,
      profileImage: payload.profileImage,
      profileImageURL: payload.profileImageURL,
      banner: payload.banner,
      theme: payload.theme,
      color: payload.color,
      photoURL: payload.photoURL,
      updatedAt: serverTimestamp()
    });
    return payload;
  }

  await setDoc(userRef, { updatedAt: serverTimestamp() }, { merge: true });
  return snap.data();
}

export function watchAuth(callback) {
  return onAuthStateChanged(auth, callback);
}

export function requireAuth(redirect = '../index.html') {
  return onAuthStateChanged(auth, (user) => {
    if (!user) location.href = redirect;
  });
}

window.loginGoogle = loginGoogle;
window.logout = logout;
